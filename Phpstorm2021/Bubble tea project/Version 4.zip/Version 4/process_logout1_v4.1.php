
<?php
session_start();
session_destroy();
header("Location: menu1_v4.1.php");

?>
